// reportWebVitals.js

// Named export for reportWebVitals function
export function reportWebVitals(metric) {
  console.log(metric);  // Logs performance metrics (like LCP, FID, etc.)
  // You can send this data to analytics or monitoring services
}
